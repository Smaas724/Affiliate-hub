// Subscription Model Framework for AffiliateHub

// Subscription tiers configuration
const subscriptionTiers = {
    free: {
        name: 'Free',
        price: 0,
        maxLinks: 25,
        features: [
            'Basic access to all networks',
            'Manual link sharing',
            'Basic analytics',
            'Limited product discovery'
        ]
    },
    premium: {
        name: 'Premium',
        price: 9.99,
        maxLinks: Infinity,
        features: [
            'Unlimited affiliate links',
            'Advanced analytics and reporting',
            'Automated posting schedules',
            'Priority support',
            'Content creation tools'
        ]
    },
    pro: {
        name: 'Pro',
        price: 19.99,
        maxLinks: Infinity,
        features: [
            'All Premium features',
            'AI-powered product recommendations',
            'Conversion optimization tools',
            'White-label link options',
            'Team collaboration features'
        ]
    }
};

// User subscription state
let userSubscription = {
    tier: 'free',
    startDate: null,
    endDate: null,
    paymentMethod: null,
    autoRenew: false
};

// Initialize subscription module
function initSubscription() {
    // Load subscription data from localStorage
    const savedSubscription = localStorage.getItem('userSubscription');
    if (savedSubscription) {
        userSubscription = JSON.parse(savedSubscription);
    }
    
    // Update UI based on subscription
    updateSubscriptionUI();
    
    // Add event listeners for subscription-related buttons
    setupSubscriptionEvents();
}

// Update UI elements based on subscription tier
function updateSubscriptionUI() {
    // Update plan badge
    const planBadge = document.querySelector('.plan-badge');
    planBadge.textContent = subscriptionTiers[userSubscription.tier].name;
    planBadge.className = 'plan-badge ' + userSubscription.tier;
    
    // Update links usage display
    const linksUsed = affiliateLinks.length;
    const maxLinks = subscriptionTiers[userSubscription.tier].maxLinks;
    const linksDisplay = document.querySelector('.subscription-info span');
    
    if (maxLinks === Infinity) {
        linksDisplay.textContent = `${linksUsed}/Unlimited used`;
    } else {
        linksDisplay.textContent = `${linksUsed}/${maxLinks} used`;
    }
    
    // Update upgrade button
    const upgradeBtn = document.querySelector('.upgrade-btn');
    if (userSubscription.tier === 'free') {
        upgradeBtn.textContent = 'Upgrade to Premium';
        upgradeBtn.style.display = 'block';
    } else if (userSubscription.tier === 'premium') {
        upgradeBtn.textContent = 'Upgrade to Pro';
        upgradeBtn.style.display = 'block';
    } else {
        upgradeBtn.style.display = 'none';
    }
    
    // Apply feature restrictions based on tier
    applyTierRestrictions();
}

// Set up event listeners for subscription-related elements
function setupSubscriptionEvents() {
    // Upgrade button
    document.querySelector('.upgrade-btn').addEventListener('click', function() {
        showUpgradeModal();
    });
}

// Show the upgrade subscription modal
function showUpgradeModal() {
    // Create modal if it doesn't exist
    if (!document.getElementById('upgrade-modal')) {
        createUpgradeModal();
    }
    
    // Determine which tier to show
    const targetTier = userSubscription.tier === 'free' ? 'premium' : 'pro';
    
    // Update modal content
    updateUpgradeModalContent(targetTier);
    
    // Show the modal
    document.getElementById('upgrade-modal').classList.add('active');
}

// Create the upgrade modal HTML
function createUpgradeModal() {
    const modalHTML = `
    <div class="modal" id="upgrade-modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Upgrade Your Subscription</h2>
                <span class="close-modal">&times;</span>
            </div>
            <div class="modal-body">
                <div class="tier-details">
                    <h3>Premium Tier</h3>
                    <div class="price">$9.99<span>/month</span></div>
                    <ul class="feature-list">
                        <li><i class="fas fa-check"></i> Unlimited affiliate links</li>
                        <li><i class="fas fa-check"></i> Advanced analytics and reporting</li>
                        <li><i class="fas fa-check"></i> Automated posting schedules</li>
                        <li><i class="fas fa-check"></i> Priority support</li>
                        <li><i class="fas fa-check"></i> Content creation tools</li>
                    </ul>
                </div>
                <div class="payment-form">
                    <h3>Payment Information</h3>
                    <div class="form-group">
                        <label for="card-name">Name on Card</label>
                        <input type="text" id="card-name" placeholder="John Doe">
                    </div>
                    <div class="form-group">
                        <label for="card-number">Card Number</label>
                        <input type="text" id="card-number" placeholder="1234 5678 9012 3456">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="card-expiry">Expiry Date</label>
                            <input type="text" id="card-expiry" placeholder="MM/YY">
                        </div>
                        <div class="form-group">
                            <label for="card-cvc">CVC</label>
                            <input type="text" id="card-cvc" placeholder="123">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>
                            <input type="checkbox" id="auto-renew" checked>
                            Auto-renew subscription
                        </label>
                    </div>
                    <button type="button" class="btn primary process-payment-btn">Upgrade Now</button>
                </div>
                <div class="payment-success" style="display: none;">
                    <i class="fas fa-check-circle"></i>
                    <h3>Upgrade Successful!</h3>
                    <p>Your subscription has been upgraded. Enjoy your new features!</p>
                    <button class="btn primary close-success-btn">Get Started</button>
                </div>
            </div>
        </div>
    </div>
    `;
    
    // Add the modal to the document
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Add event listeners
    document.querySelector('#upgrade-modal .close-modal').addEventListener('click', function() {
        document.getElementById('upgrade-modal').classList.remove('active');
    });
    
    document.querySelector('.process-payment-btn').addEventListener('click', function() {
        processPayment();
    });
    
    document.querySelector('.close-success-btn').addEventListener('click', function() {
        document.getElementById('upgrade-modal').classList.remove('active');
    });
}

// Update the upgrade modal content based on target tier
function updateUpgradeModalContent(targetTier) {
    const tierDetails = document.querySelector('#upgrade-modal .tier-details');
    const tier = subscriptionTiers[targetTier];
    
    tierDetails.querySelector('h3').textContent = `${tier.name} Tier`;
    tierDetails.querySelector('.price').innerHTML = `$${tier.price}<span>/month</span>`;
    
    const featureList = tierDetails.querySelector('.feature-list');
    featureList.innerHTML = '';
    
    tier.features.forEach(feature => {
        const li = document.createElement('li');
        li.innerHTML = `<i class="fas fa-check"></i> ${feature}`;
        featureList.appendChild(li);
    });
}

// Process the payment and upgrade the subscription
function processPayment() {
    // In a real app, this would connect to a payment processor
    // For this demo, we'll simulate a successful payment
    
    // Show loading state
    const paymentBtn = document.querySelector('.process-payment-btn');
    paymentBtn.textContent = 'Processing...';
    paymentBtn.disabled = true;
    
    // Simulate payment processing
    setTimeout(() => {
        // Determine the new tier
        const newTier = userSubscription.tier === 'free' ? 'premium' : 'pro';
        
        // Update subscription
        userSubscription = {
            tier: newTier,
            startDate: new Date().toISOString(),
            endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
            paymentMethod: 'credit_card',
            autoRenew: document.getElementById('auto-renew').checked
        };
        
        // Save to localStorage
        localStorage.setItem('userSubscription', JSON.stringify(userSubscription));
        
        // Update UI
        updateSubscriptionUI();
        
        // Show success message
        document.querySelector('.payment-form').style.display = 'none';
        document.querySelector('.payment-success').style.display = 'block';
    }, 2000);
}

// Apply feature restrictions based on subscription tier
function applyTierRestrictions() {
    const tier = userSubscription.tier;
    const maxLinks = subscriptionTiers[tier].maxLinks;
    
    // Check if user has reached link limit
    if (affiliateLinks.length >= maxLinks && maxLinks !== Infinity) {
        // Disable link creation buttons
        document.getElementById('create-link-btn').disabled = true;
        document.getElementById('new-link-btn').disabled = true;
        document.getElementById('create-first-link').disabled = true;
        
        // Show upgrade message
        if (!document.querySelector('.link-limit-warning')) {
            const warning = document.createElement('div');
            warning.className = 'link-limit-warning';
            warning.innerHTML = `
                <p>You've reached your limit of ${maxLinks} links on the ${subscriptionTiers[tier].name} plan.</p>
                <button class="btn primary upgrade-from-warning-btn">Upgrade Now</button>
            `;
            
            document.querySelector('#links .section-header').appendChild(warning);
            
            // Add event listener to the new button
            document.querySelector('.upgrade-from-warning-btn').addEventListener('click', function() {
                showUpgradeModal();
            });
        }
    } else {
        // Enable link creation buttons
        document.getElementById('create-link-btn').disabled = false;
        document.getElementById('new-link-btn').disabled = false;
        document.getElementById('create-first-link').disabled = false;
        
        // Remove warning if it exists
        const warning = document.querySelector('.link-limit-warning');
        if (warning) {
            warning.remove();
        }
    }
    
    // Apply other tier-specific restrictions
    if (tier === 'free') {
        // Disable premium features
        document.querySelectorAll('.premium-feature').forEach(el => {
            el.classList.add('disabled');
            el.setAttribute('data-tooltip', 'Upgrade to Premium to unlock this feature');
        });
    } else {
        // Enable premium features
        document.querySelectorAll('.premium-feature').forEach(el => {
            el.classList.remove('disabled');
            el.removeAttribute('data-tooltip');
        });
        
        // Handle pro-only features
        if (tier !== 'pro') {
            document.querySelectorAll('.pro-feature').forEach(el => {
                el.classList.add('disabled');
                el.setAttribute('data-tooltip', 'Upgrade to Pro to unlock this feature');
            });
        } else {
            document.querySelectorAll('.pro-feature').forEach(el => {
                el.classList.remove('disabled');
                el.removeAttribute('data-tooltip');
            });
        }
    }
}

// Add subscription initialization to the main init function
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the application
    initApp();
    
    // Set up event listeners
    setupEventListeners();
    
    // Load any saved data
    loadSavedData();
    
    // Initialize subscription module
    initSubscription();
});
